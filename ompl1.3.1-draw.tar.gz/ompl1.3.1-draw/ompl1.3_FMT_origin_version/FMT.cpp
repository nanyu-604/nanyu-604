﻿/*********************************************************************
* Software License Agreement (BSD License)
*
*  Copyright (c) 2013, Autonomous Systems Laboratory, Stanford University
*  All rights reserved.
*
*  Redistribution and use in source and binary forms, with or without
*  modification, are permitted provided that the following conditions
*  are met:
*
*   * Redistributions of source code must retain the above copyright
*     notice, this list of conditions and the following disclaimer.
*   * Redistributions in binary form must reproduce the above
*     copyright notice, this list of conditions and the following
*     disclaimer in the documentation and/or other materials provided
*     with the distribution.
*   * Neither the name of Stanford University nor the names of its
*     contributors may be used to endorse or promote products derived
*     from this software without specific prior written permission.
*
*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
*  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
*  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
*  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
*  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
*  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
*  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
*  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
*  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
*  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
*  POSSIBILITY OF SUCH DAMAGE.
*********************************************************************/

/* Authors: Ashley Clark (Stanford) and Wolfgang Pointner (AIT) */
/* Co-developers: Brice Rebsamen (Stanford), Tim Wheeler (Stanford)
                  Edward Schmerling (Stanford), and Javier V. Gómez (UC3M - Stanford)*/
/* Algorithm design: Lucas Janson (Stanford) and Marco Pavone (Stanford) */
/* Acknowledgements for insightful comments: Oren Salzman (Tel Aviv University),
 *                                           Joseph Starek (Stanford) */

#include <limits>
#include <iostream>

#include <boost/math/constants/constants.hpp>
#include <boost/math/distributions/binomial.hpp>

#include <ompl/datastructures/BinaryHeap.h>
#include <ompl/tools/config/SelfConfig.h>
#include <ompl/base/objectives/PathLengthOptimizationObjective.h>
#include <ompl/geometric/planners/fmt/FMT.h>

//original code with paint

ompl::geometric::FMT::FMT(const base::SpaceInformationPtr &si)
  : base::Planner(si, "FMT")
{
    // An upper bound on the free space volume is the total space volume; the free fraction is estimated in sampleFree
    freeSpaceVolume_ = si_->getStateSpace()->getMeasure();
    lastGoalMotion_ = nullptr;

    specs_.approximateSolutions = false;
    specs_.directed = false;

    ompl::base::Planner::declareParam<unsigned int>("num_samples", this, &FMT::setNumSamples, &FMT::getNumSamples,
                                                    "10:10:1000000");
    ompl::base::Planner::declareParam<double>("radius_multiplier", this, &FMT::setRadiusMultiplier,
                                              &FMT::getRadiusMultiplier, "0.1:0.05:50.");
    ompl::base::Planner::declareParam<bool>("nearest_k", this, &FMT::setNearestK, &FMT::getNearestK, "0,1");
    ompl::base::Planner::declareParam<bool>("cache_cc", this, &FMT::setCacheCC, &FMT::getCacheCC, "0,1");
    ompl::base::Planner::declareParam<bool>("heuristics", this, &FMT::setHeuristics, &FMT::getHeuristics, "0,1");
    ompl::base::Planner::declareParam<bool>("extended_fmt", this, &FMT::setExtendedFMT, &FMT::getExtendedFMT, "0,1");
}

ompl::geometric::FMT::~FMT()
{
    freeMemory();
}

void ompl::geometric::FMT::setup()
{
    if (pdef_)
    {
        /* Setup the optimization objective. If no optimization objective was
        specified, then default to optimizing path length as computed by the
        distance() function in the state space */
        if (pdef_->hasOptimizationObjective())
            opt_ = pdef_->getOptimizationObjective();
        else
        {
            OMPL_INFORM("%s: No optimization objective specified. Defaulting to optimizing path length.",
                        getName().c_str());
            opt_ = std::make_shared<base::PathLengthOptimizationObjective>(si_);
            // Store the new objective in the problem def'n
            pdef_->setOptimizationObjective(opt_);
        }
        Open_.getComparisonOperator().opt_ = opt_.get();
        Open_.getComparisonOperator().heuristics_ = heuristics_;

        if (!nn_)
            nn_.reset(tools::SelfConfig::getDefaultNearestNeighbors<Motion *>(this));
        nn_->setDistanceFunction([this](const Motion *a, const Motion *b)
                                 {
                                     return distanceFunction(a, b);
                                 });

        if (nearestK_ && !nn_->reportsSortedResults())
        {
            OMPL_WARN("%s: NearestNeighbors datastructure does not return sorted solutions. Nearest K strategy "
                      "disabled.",
                      getName().c_str());
            nearestK_ = false;
        }
    }
    else
    {
        OMPL_INFORM("%s: problem definition is not set, deferring setup completion...", getName().c_str());
        setup_ = false;
    }
}

void ompl::geometric::FMT::freeMemory()
{
    if (nn_)
    {
        std::vector<Motion *> motions;
        motions.reserve(nn_->size());
        nn_->list(motions);
        for (auto &motion : motions)
        {
            si_->freeState(motion->getState());
            delete motion;
        }
    }
}

void ompl::geometric::FMT::clear()
{
    Planner::clear();
    lastGoalMotion_ = nullptr;
    sampler_.reset();
    freeMemory();
    if (nn_)
        nn_->clear();
    Open_.clear();
    neighborhoods_.clear();

    collisionChecks_ = 0;
}

void ompl::geometric::FMT::getPlannerData(base::PlannerData &data) const
{
    Planner::getPlannerData(data);
    std::vector<Motion *> motions;
    nn_->list(motions);

    if (lastGoalMotion_ != nullptr)
        data.addGoalVertex(base::PlannerDataVertex(lastGoalMotion_->getState()));

    unsigned int size = motions.size();
    for (unsigned int i = 0; i < size; ++i)
    {
        if (motions[i]->getParent() == nullptr)
            data.addStartVertex(base::PlannerDataVertex(motions[i]->getState()));
        else
            data.addEdge(base::PlannerDataVertex(motions[i]->getParent()->getState()),
                         base::PlannerDataVertex(motions[i]->getState()));
    }
}

void ompl::geometric::FMT::saveNeighborhood(Motion *m)
{
    // Check to see if neighborhood has not been saved yet
    if (neighborhoods_.find(m) == neighborhoods_.end())
    {
        std::vector<Motion *> nbh;
        if (nearestK_)
            nn_->nearestK(m, NNk_, nbh);/*把m点的k最邻近点放进nbh容器中*/
        else
            nn_->nearestR(m, NNr_, nbh);
        if (!nbh.empty())
        {
            // Save the neighborhood but skip the first element, since it will be motion m
            neighborhoods_[m] = std::vector<Motion *>(nbh.size() - 1, nullptr);
            std::copy(nbh.begin() + 1, nbh.end(), neighborhoods_[m].begin());
        }
        else
        {
            // Save an empty neighborhood
            neighborhoods_[m] = std::vector<Motion *>(0);
        }
    }  // If neighborhood hadn't been saved yet
}

// Calculate the unit ball volume for a given dimension
double ompl::geometric::FMT::calculateUnitBallVolume(const unsigned int dimension) const
{
    if (dimension == 0)
        return 1.0;
    if (dimension == 1)
        return 2.0;
    return 2.0 * boost::math::constants::pi<double>() / dimension * calculateUnitBallVolume(dimension - 2);
}

double ompl::geometric::FMT::calculateRadius(const unsigned int dimension, const unsigned int n) const
{
    double a = 1.0 / (double)dimension;
    double unitBallVolume = calculateUnitBallVolume(dimension);

    return radiusMultiplier_ * 2.0 * std::pow(a, a) * std::pow(freeSpaceVolume_ / unitBallVolume, a) *
           std::pow(log((double)n) / (double)n, a);
}

void ompl::geometric::FMT::sampleFree(const base::PlannerTerminationCondition &ptc)
{
    unsigned int nodeCount = 0;
    unsigned int sampleAttempts = 0;
    auto *motion = new Motion(si_);

    // Sample numSamples_ number of nodes from the free configuration space
    while (nodeCount < numSamples_ && !ptc)
    {
        sampler_->sampleUniform(motion->getState());
        sampleAttempts++;

        bool collision_free = si_->isValid(motion->getState());

        if (collision_free)
        {
            nodeCount++;
            nn_->add(motion);
            motion = new Motion(si_);
        }  // If collision free
    }      // While nodeCount < numSamples
    si_->freeState(motion->getState());
    delete motion;

    // 95% confidence limit for an upper bound for the true free space volume
    freeSpaceVolume_ = boost::math::binomial_distribution<>::find_upper_bound_on_p(sampleAttempts, nodeCount, 0.05) *
                       si_->getStateSpace()->getMeasure();
}

void ompl::geometric::FMT::assureGoalIsSampled(const ompl::base::GoalSampleableRegion *goal)
{
    // Ensure that there is at least one node near each goal
    while (const base::State *goalState = pis_.nextGoal())
    {
        auto *gMotion = new Motion(si_);
        si_->copyState(gMotion->getState(), goalState);

        std::vector<Motion *> nearGoal;
        nn_->nearestR(gMotion, goal->getThreshold(), nearGoal);

        // If there is no node in the goal region, insert one
        if (nearGoal.empty())
        {
            OMPL_DEBUG("No state inside goal region");
            if (si_->getStateValidityChecker()->isValid(gMotion->getState()))
            {
                nn_->add(gMotion);
                goalState_ = gMotion->getState();
            }
            else
            {
                si_->freeState(gMotion->getState());
                delete gMotion;
            }
        }
        else  // There is already a sample in the goal region
        {
            goalState_ = nearGoal[0]->getState();
            si_->freeState(gMotion->getState());
            delete gMotion;
        }
    }  // For each goal
}

ompl::base::PlannerStatus ompl::geometric::FMT::solve(const base::PlannerTerminationCondition &ptc)
{
    if (lastGoalMotion_ != nullptr)
    {
        OMPL_INFORM("solve() called before clear(); returning previous solution");
        traceSolutionPathThroughTree(lastGoalMotion_);
        OMPL_DEBUG("Final path cost: %f", lastGoalMotion_->getCost().value());
        return base::PlannerStatus(true, false);
    }
    if (!Open_.empty())
    {
        OMPL_INFORM("solve() called before clear(); no previous solution so starting afresh");
        clear();
    }

    checkValidity();
    auto *goal = dynamic_cast<base::GoalSampleableRegion *>(pdef_->getGoal().get());
    Motion *initMotion = nullptr;

    if (goal == nullptr)
    {
        OMPL_ERROR("%s: Unknown type of goal", getName().c_str());
        return base::PlannerStatus::UNRECOGNIZED_GOAL_TYPE;
    }

    // Add start states to V (nn_) and Open
    while (const base::State *st = pis_.nextStart())
    {
        initMotion = new Motion(si_);
        si_->copyState(initMotion->getState(), st);
        Open_.insert(initMotion);
        initMotion->setSetType(Motion::SET_OPEN);
        initMotion->setCost(opt_->initialCost(initMotion->getState()));
        nn_->add(initMotion);  // V <-- {x_init}
    }

    if (initMotion == nullptr)
    {
        OMPL_ERROR("Start state undefined");
        return base::PlannerStatus::INVALID_START;
    }

    // Sample N free states in the configuration space
    if (!sampler_)
        sampler_ = si_->allocStateSampler();
    sampleFree(ptc);
    assureGoalIsSampled(goal);
    OMPL_INFORM("%s: Starting planning with %u states already in datastructure", getName().c_str(), nn_->size());

    // Calculate the nearest neighbor search radius
    /// \todo Create a PRM-like connection strategy
    if (nearestK_)
    {/*floor()是向负无穷大舍入，floor(-10.5) == -11；
                ceil()是向正无穷大舍入，ceil(-10.5) == -10*/
        NNk_ = std::ceil(std::pow(2.0 * radiusMultiplier_, (double)si_->getStateDimension()) *
                         (boost::math::constants::e<double>() / (double)si_->getStateDimension()) *
                         log((double)nn_->size()));
        OMPL_DEBUG("Using nearest-neighbors k of %d", NNk_);
    }
    else
    {
        NNr_ = calculateRadius(si_->getStateDimension(), nn_->size());
        OMPL_DEBUG("Using radius of %f", NNr_);
    }

    // Execute the planner, and return early if the planner returns a failure
    bool plannerSuccess = false;
    bool successfulExpansion = false;
    Motion *z = initMotion;  // z <-- xinit
    saveNeighborhood(z);

    while (!ptc)
    {
        if ((plannerSuccess = goal->isSatisfied(z->getState())))
            break;

        successfulExpansion = expandTreeFromNode(&z);

         drawPathe();//


        if (!extendedFMT_ && !successfulExpansion)
            break;

//        never mind below
//        插入一个采样点，如果成功添加进树上，则将其置为open，设为新的z点并开始拓展，也就是每次只添加一个采样点，而且直到成功添加一个采样点之前不会跳出
        if (extendedFMT_ && !successfulExpansion)
        {
            // Apply RRT*-like connections: sample and connect samples to tree
            std::vector<Motion *> nbh;
            std::vector<base::Cost> costs;/*采样点经过树的总cost*/
           std::vector<base::Cost> incCosts;/*树上点到采样点直线距离*/
            std::vector<std::size_t> sortedCostIndices;

            // our functor for sorting nearest neighbors
            CostIndexCompare compareFn(costs, *opt_);

//             drawPathe();//

            auto *m = new Motion(si_);
            while (!ptc && Open_.empty())/*如果open集为空但是没找到解*/
            {
                sampler_->sampleUniform(m->getState());/*重新在空间里采一个点*/

                if (!si_->isValid(m->getState()))
                    continue;

                if (nearestK_)
                    nn_->nearestK(m, NNk_, nbh);/*找到采样点的nearest neighbor集，并放入nbh*/
                else
                    nn_->nearestR(m, NNr_, nbh);

                // Get neighbours in the tree.
                std::vector<Motion *> yNear;
                yNear.reserve(nbh.size());
                for (auto &j : nbh)
                {
                    if (j->getSetType() == Motion::SET_CLOSED)
                    {
                        if (nearestK_)
                        {
                            // Only include neighbors that are mutually k-nearest
                            // Relies on NN datastructure returning k-nearest in sorted order
                            const base::Cost connCost = opt_->motionCost(j->getState(), m->getState());
                            const base::Cost worstCost =
                                opt_->motionCost(neighborhoods_[j].back()->getState(), j->getState());

                            if (opt_->isCostBetterThan(worstCost, connCost))
                                continue;
/*continue语句和break语句的区别是：continue语句只结束本次循环，而不是终止整个循环的执行。而break语句则是结束本次循环，不再进行条件判断。*/
                            yNear.push_back(j);
                        }
                        else
                            yNear.push_back(j);
                    }
                }

                // Sample again if the new sample does not connect to the tree.
                if (yNear.empty())
                    continue;

                // cache for distance computations
                //
                // Our cost caches only increase in size, so they're only
                // resized if they can't fit the current neighborhood
                if (costs.size() < yNear.size())/*开辟内存空间*/
                {
                    costs.resize(yNear.size());
                    incCosts.resize(yNear.size());
                    sortedCostIndices.resize(yNear.size());
                }

                // Finding the nearest neighbor to connect to
                // By default, neighborhood states are sorted by cost, and collision checking
                // is performed in increasing order of cost
                //
                // calculate all costs and distances
                for (std::size_t i = 0; i < yNear.size(); ++i)
                {
                    incCosts[i] = opt_->motionCost(yNear[i]->getState(), m->getState());
                    costs[i] = opt_->combineCosts(yNear[i]->getCost(), incCosts[i]);
                }

                // sort the nodes
                //
                // we're using index-value pairs so that we can get at
                // original, unsorted indices
                for (std::size_t i = 0; i < yNear.size(); ++i)
                    sortedCostIndices[i] = i;
                std::sort(sortedCostIndices.begin(), sortedCostIndices.begin() + yNear.size(), compareFn);

                // collision check until a valid motion is found
                for (std::vector<std::size_t>::const_iterator i = sortedCostIndices.begin();
                     i != sortedCostIndices.begin() + yNear.size(); ++i)
                {
                    if (si_->checkMotion(yNear[*i]->getState(), m->getState()))
                    {
                        m->setParent(yNear[*i]);
                        yNear[*i]->getChildren().push_back(m);
                        const base::Cost incCost = opt_->motionCost(yNear[*i]->getState(), m->getState());
                        m->setCost(opt_->combineCosts(yNear[*i]->getCost(), incCost));
                        m->setHeuristicCost(opt_->motionCostHeuristic(m->getState(), goalState_));
                        m->setSetType(Motion::SET_OPEN);

//                        //        //modify begin 实现重新选择父节点parent
//                        if (yNear[*i]->getParent() != nullptr)
//                        {
//                             base::Cost adist = opt_->motionCost(m->getState(), yNear[*i]->getParent()->getState());
//                             base::Cost acNew = opt_->combineCosts(yNear[*i]->getParent()->getCost(), adist);
//                            if(opt_->isCostBetterThan(acNew, m->getCost()) && si_->checkMotion(yNear[*i]->getParent()->getState(), m->getState()))
//                            {
//                                // Remove this node from its parent list
//                                removeFromParent(m);//

//                                // Add this node to the new parent
//                                m->setParent(yNear[*i]->getParent());
//                                m->getParent()->getChildren().push_back(m);
//                                m->setCost(acNew);
//                                m->setHeuristicCost(opt_->motionCostHeuristic(m->getState(), goalState_));

//                //                std::cout << "第" << i << "次xacost: " << x->getCost() << std::endl;//test code

//                            }

//                        }

//                                //modify end

                        nn_->add(m);

                        updateNeighborhood(m, nbh);//专用函数，m点插入后，将其加入到其邻近点的neighborhood中
                         saveNeighborhood(m);

                        Open_.insert(m);
                        z = m;
                        break;
                    }
                }

//           //modify begin
//           //            实现重新布线

//                for (std::size_t i = 0; i < yNear.size(); ++i)
//                {
//                    if (yNear[i] != m->getParent())
//                    {
//                        base::Cost nbhIncCost;/*m与nbh之间的代价*/
//                        nbhIncCost = opt_->motionCost(m->getState(), yNear[i]->getState());
//                        base::Cost nbhNewCost = opt_->combineCosts(m->getCost(), nbhIncCost);/*nbh经由Xnew点的代价值*/
//                        if (opt_->isCostBetterThan(nbhNewCost, yNear[i]->getCost()) &&  si_->checkMotion(m->getState(),yNear[i]->getState()))
//                        {

//                                // Remove this node from its parent list
//                                removeFromParent(yNear[i]);//

//                                // Add this node to the new parent
//                                yNear[i]->setParent(m) ;
//                                yNear[i]->inc_Cost = nbhIncCost;
//                                yNear[i]->getCost() = nbhNewCost;
//                                yNear[i]->getParent()->getChildren().push_back(yNear[i]);

//                                // Update the costs of the node's children
//                                updateChildCosts(yNear[i]);//

//                            //modify begin 实现重新布线的父节点parent
//                            if (m->getParent() != nullptr)
//                            {
//                                base::Cost nbhaIncCost;

//                                 nbhaIncCost = opt_->motionCost(m->getParent()->getState(), yNear[i]->getState());
//                                 base::Cost nbhaNewCost = opt_->combineCosts(m->getParent()->getCost(), nbhaIncCost);
//                                if(opt_->isCostBetterThan(nbhaNewCost, yNear[i]->getCost()) && si_->checkMotion(m->getParent()->getState(), yNear[i]->getState()))
//                                {
//                                    // Remove this node from its parent list
//                                    removeFromParent(yNear[i]);//

//                                    // Add this node to the new parent
//                                    yNear[i]->setParent(m->getParent());
//                                    yNear[i]->inc_Cost = nbhaIncCost;
//                                    yNear[i]->getCost() = nbhaNewCost;
//                                    yNear[i]->getParent()->getChildren().push_back(yNear[i]);

//                                    // Update the costs of the node's children
//                                    updateChildCosts(yNear[i]);//

//                                }
//                            }
////                           modify end

//                         }
//                    }

//              }
//            //            重新布线过程结束
//                        //modify end

//                drawPathe();

            }  // while (!ptc && Open_.empty())
        }      // else if (extendedFMT_ && !successfulExpansion)
    }          // While not at goal
//never mind above

    if (plannerSuccess)
    {
        // Return the path to z, since by definition of planner success, z is in the goal region
        lastGoalMotion_ = z;
        traceSolutionPathThroughTree(lastGoalMotion_);
        OMPL_DEBUG("Final path cost: %f", lastGoalMotion_->getCost().value());

            drawPathe();//绘制蓝色的最终路线

        return base::PlannerStatus(true, false);
    }  // if plannerSuccess

    // Planner terminated without accomplishing goal
    return base::PlannerStatus(false, false);
}

//modify
void ompl::geometric::FMT::updateChildCosts(Motion *m)
{
    for (std::size_t i = 0; i < m->getChildren().size(); ++i)
    {
        m->getChildren()[i]->getCost() = opt_->combineCosts(m->getCost(), m->getChildren()[i]->inc_Cost);
        updateChildCosts(m->getChildren()[i]);/*递归调用*/
    }
}

bool ompl::geometric::FMT::expandTreeFromNode(Motion **z)
{
    // Find all nodes that are near z, and also in set Unvisited

    std::vector<Motion *> xNear;/*xNear：z点附近未访问点的集合*/
    const std::vector<Motion *> &zNeighborhood = neighborhoods_[*z];/*zNeighborhood：z点附近点的集合*/
    const unsigned int zNeighborhoodSize = zNeighborhood.size();
    xNear.reserve(zNeighborhoodSize);

    for (unsigned int i = 0; i < zNeighborhoodSize; ++i)
    {
        Motion *x = zNeighborhood[i];
        if (x->getSetType() == Motion::SET_UNVISITED)
        {
            saveNeighborhood(x);
            if (nearestK_)
            {
                // Only include neighbors that are mutually k-nearest
                // Relies on NN datastructure returning k-nearest in sorted order
                const base::Cost connCost = opt_->motionCost((*z)->getState(), x->getState());
                const base::Cost worstCost = opt_->motionCost(neighborhoods_[x].back()->getState(), x->getState());

                if (opt_->isCostBetterThan(worstCost, connCost))
                    continue;
                xNear.push_back(x);
            }
            else
                xNear.push_back(x);
        }
    }

    // For each node near z and in set Unvisited, attempt to connect it to set Open
    std::vector<Motion *> yNear;/*xNear:z点附近unvisited点集；yNear：xNear中的点附近的树上节点集合*/
    std::vector<Motion *> Open_new;
    const unsigned int xNearSize = xNear.size();
    for (unsigned int i = 0; i < xNearSize; ++i)
    {
//        Motion *x = xNear[i];

//        // Find all nodes that are near x and in set Open
//        const std::vector<Motion *> &xNeighborhood = neighborhoods_[x];/*xNeighborhood：x点附近点集合*/

//        const unsigned int xNeighborhoodSize = xNeighborhood.size();
//        yNear.reserve(xNeighborhoodSize);
//        for (unsigned int j = 0; j < xNeighborhoodSize; ++j)
//        {
//            if (xNeighborhood[j]->getSetType() == Motion::SET_OPEN)
//                yNear.push_back(xNeighborhood[j]);
//        }

//        // Find the lowest cost-to-come connection from Open to x
//        base::Cost cMin(std::numeric_limits<double>::infinity());

//         Motion *yMin  = getBestParent(x, yNear, cMin);
//        yNear.clear();

//        // If an optimal connection from Open to x was found
//        if (yMin != nullptr)
//        {
//            bool collision_free = false;
//            if (cacheCC_)
//            {
//                if (!yMin->alreadyCC(x))
//                {
//                    collision_free = si_->checkMotion(yMin->getState(), x->getState());
//                    ++collisionChecks_;
//                    // Due to FMT* design, it is only necessary to save unsuccesful
//                    // connection attemps because of collision
//                    if (!collision_free)
//                        yMin->addCC(x);
//                }
//            }
//            else
//            {
//                ++collisionChecks_;
//                collision_free = si_->checkMotion(yMin->getState(), x->getState());
//            }

//            if (collision_free)
//            {
//                // Add edge from yMin to x
//                x->setParent(yMin);
//                x->setCost(cMin);
//                x->setHeuristicCost(opt_->motionCostHeuristic(x->getState(), goalState_));
//                x->getParent()->getChildren().push_back(x);

////            std::cout << "第" << i << "次xcost: " << x->getCost() << std::endl;//test code

//                // Add x to Open
//                Open_new.push_back(x);
//                // Remove x from Unvisited
//                x->setSetType(Motion::SET_CLOSED);/*x点已经复制进open集合了，原x点直接放进closed*/
//            }

////            //        //modify begin 实现重选父节点parent
////            if (yMin->getParent() != nullptr && collision_free)
////            {
////                 base::Cost adist = opt_->motionCost(x->getState(), yMin->getParent()->getState());
////                 base::Cost acNew = opt_->combineCosts(yMin->getParent()->getCost(), adist);
////                if(opt_->isCostBetterThan(acNew, x->getCost()) && si_->checkMotion(yMin->getParent()->getState(), x->getState()))
////                {
////                    // Remove this node from its parent list
////                    removeFromParent(x);//

////                    // Add this node to the new parent
////                    x->setParent(yMin->getParent());
////                    x->setCost(acNew);
////                    x->setHeuristicCost(opt_->motionCostHeuristic(x->getState(), goalState_));
////                    x->getParent()->getChildren().push_back(x);
////    //                std::cout << "第" << i << "次xacost: " << x->getCost() << std::endl;//test code

////    //                            Open_new.push_back(x);
////    //                         x->setSetType(Motion::SET_CLOSED);
////                }
////            }

////                    //modify end

//        }  // An optimal connection from Open to x was found


        //modify begin
        Motion *x = xNear[i];
       std::vector<Motion *>hNear;
        // Find all nodes that are near x and in set Open
        const std::vector<Motion *> &xNeighborhood = neighborhoods_[x];/*xNeighborhood：x点附近点集合*/

        const unsigned int xNeighborhoodSize = xNeighborhood.size();
        yNear.reserve(xNeighborhoodSize);

        hNear.reserve(xNeighborhoodSize);

        //modify begin 我想设置为1-2之间的碰撞检测次数
        Motion *ymin=nullptr;

        std::vector<base::Cost>ycim;
        for (unsigned int j = 0; j < xNeighborhoodSize; ++j)
        {
            if (xNeighborhood[j]->getSetType() == Motion::SET_OPEN)
            {
              if(xNeighborhood[j]->getParent()!=nullptr)
                yNear.push_back(xNeighborhood[j]->getParent());
              else
                  yNear.push_back(xNeighborhood[j]);
            }
        }
        for(unsigned int j=0; j<xNeighborhoodSize; ++j)
        {
            if(xNeighborhood[j]->getSetType()==Motion::SET_OPEN)
            {
                hNear.push_back(xNeighborhood[j]);
            }
        }

        base::Cost xcim=opt_->infiniteCost();

        ymin=getBestParent(x,yNear,xcim);



        if(ymin!=nullptr)
        {

            bool Ancestrycollisionfree=false;
            if(cacheCC_)
            {

                if(!ymin->alreadyCC(x))
                {
                    Ancestrycollisionfree=si_->checkMotion(ymin->getState(),x->getState());
                    if(!Ancestrycollisionfree)
                        ymin->addCC(x);
                }
            }
            else
            {
                Ancestrycollisionfree=si_->checkMotion(ymin->getState(),x->getState());
            }

            if(Ancestrycollisionfree)//这是一次对祖先节点的检测
            {
                if(x->getParent()==ymin)
                    removeFromParent(x);
                x->setParent(ymin);
                x->setCost(xcim);
                x->setHeuristicCost(opt_->motionCostHeuristic(x->getState(),goalState_));
                x->getParent()->getChildren().push_back(x);
                Open_new.push_back(x);
                x->setSetType(Motion::SET_CLOSED);//将x点设置为一个close点
            }
            if(!Ancestrycollisionfree)//这个时候出现第一次选择祖先节点失败，那么就选择普通的拓展模式
            {
                bool collisionfree=false;
                std::vector<base::Cost>  cim;
                base::Cost hcim=opt_->infiniteCost();
                Motion *yhmin=getBestParent(x,hNear,hcim);
                if(yhmin!=nullptr)

                 {
                    if(cacheCC_)
                    {
                        if(!yhmin->alreadyCC(x))
                        {
                            collisionfree=si_->checkMotion(x->getState(),yhmin->getState());
                            if(!collisionfree)
                                yhmin->addCC(x);
                        }
                    }
                    else
                    {
                       collisionfree=si_->checkMotion(x->getState(),yhmin->getState());
                    }
                    if(collisionfree)
                    {
                        if(x->getParent()==yhmin)
                            removeFromParent(x);
                        x->setParent(yhmin);
                        x->setCost(hcim);
                        x->setHeuristicCost(opt_->motionCostHeuristic(x->getState(),goalState_));
                        x->getParent()->getChildren().push_back(x);
                        Open_new.push_back(x);
                        x->setSetType(Motion::SET_CLOSED);
                    }



              }
            }
        }
        hNear.clear();
        yNear.clear();

    }      // For each node near z and in set Unvisited, try to connect it to set Open

    // Update Open
    Open_.pop();
    (*z)->setSetType(Motion::SET_CLOSED);

    // Add the nodes in Open_new to Open
    unsigned int openNewSize = Open_new.size();
    for (unsigned int i = 0; i < openNewSize; ++i)
    {
        Open_.insert(Open_new[i]);
        Open_new[i]->setSetType(Motion::SET_OPEN);
    }
    Open_new.clear();/*删除原来的容器*/

    if (Open_.empty())
    {
        if (!extendedFMT_)
            OMPL_INFORM("Open is empty before path was found --> no feasible path exists");
        return false;
    }

    // Take the top of Open as the new z
    *z = Open_.top()->data;

    return true;
}

void ompl::geometric::FMT::removeFromParent(Motion *m)
{
    for (auto it = m->getParent()->getChildren().begin(); it != m->getParent()->getChildren().end(); ++it)
    {
        if (*it == m)//对迭代器进行解引用
        {
            m->getParent()->getChildren().erase(it);
            break;
        }
    }
}

ompl::geometric::FMT::Motion *ompl::geometric::FMT::getBestParent(Motion *m, std::vector<Motion *> &neighbors,
                                                                  base::Cost &cMin)
{
    Motion *min = nullptr;
    const unsigned int neighborsSize = neighbors.size();
    for (unsigned int j = 0; j < neighborsSize; ++j)
    {
        const base::State *s = neighbors[j]->getState();
        const base::Cost dist = opt_->motionCost(s, m->getState());
        const base::Cost cNew = opt_->combineCosts(neighbors[j]->getCost(), dist);

        if (opt_->isCostBetterThan(cNew, cMin))
        {
            min = neighbors[j];
            cMin = cNew;
        }
    }
    return min;
}

//extendFMT 专用函数
void ompl::geometric::FMT::updateNeighborhood(Motion *m, const std::vector<Motion *> nbh)
{
    for (auto i : nbh)
    {
        // If CLOSED, the neighborhood already exists. If neighborhood already exists, we have
        // to insert the node in the corresponding place of the neighborhood of the neighbor of m.
        if (i->getSetType() == Motion::SET_CLOSED || neighborhoods_.find(i) != neighborhoods_.end())
        {
            const base::Cost connCost = opt_->motionCost(i->getState(), m->getState());
            const base::Cost worstCost = opt_->motionCost(neighborhoods_[i].back()->getState(), i->getState());//m点neighborhood中代价最大点

            if (opt_->isCostBetterThan(worstCost, connCost))
                continue;

            // Insert the neighbor in the vector in the correct order
            std::vector<Motion *> &nbhToUpdate = neighborhoods_[i];
            for (std::size_t j = 0; j < nbhToUpdate.size(); ++j)
            {
                // If connection to the new state is better than the current neighbor tested, insert.
                const base::Cost cost = opt_->motionCost(i->getState(), nbhToUpdate[j]->getState());
                if (opt_->isCostBetterThan(connCost, cost))
                {
                    nbhToUpdate.insert(nbhToUpdate.begin() + j, m);
                    break;
                }
            }
        }
        else//m点附近的unvisited点
        {
            std::vector<Motion *> nbh2;
            if (nearestK_)
                nn_->nearestK(m, NNk_, nbh2);
            else
                nn_->nearestR(m, NNr_, nbh2);

            if (!nbh2.empty())
            {
                // Save the neighborhood but skip the first element, since it will be motion m
                neighborhoods_[i] = std::vector<Motion *>(nbh2.size() - 1, nullptr);
                std::copy(nbh2.begin() + 1, nbh2.end(), neighborhoods_[i].begin());
            }
            else
            {
                // Save an empty neighborhood
                neighborhoods_[i] = std::vector<Motion *>(0);
            }
        }
    }
}


void ompl::geometric::FMT::traceSolutionPathThroughTree(Motion *goalMotion)
{
//    std::vector<Motion *> mpath;
    Motion *solution = goalMotion;

    // Construct the solution path
    while (solution != nullptr)
    {
        mpath.push_back(solution);
        solution = solution->getParent();
    }

    // Set the solution path
    auto path(std::make_shared<PathGeometric>(si_));
    mPathSize = mpath.size();
    for (int i = mPathSize - 1; i >= 0; --i)
        path->append(mpath[i]->getState());
    pdef_->addSolutionPath(path, false, -1.0, getName());
}

void ompl::geometric::FMT::drawPathe()
{
    // 显示并输出最终规划路径图像，并输出图像文件
    Mat envImageCopy; // 复制后的图像变量
    Mat envImageResize; // 修改图像尺寸后点图像变量
    envImage_.copyTo(envImageCopy); // 复制图像
    std::vector<Motion *> drawMotions;
    nn_->list(drawMotions); // 将树上的数据存入testMotions中
    for (Motion *drawMotion : drawMotions) // 遍历树上点数据
    {
        double stateX = drawMotion->getState()->as<ompl::base::RealVectorStateSpace::StateType>()->values[0]; // 树上数据点的x，y值
        double stateY = drawMotion->getState()->as<ompl::base::RealVectorStateSpace::StateType>()->values[1];
        circle( envImageCopy,Point( stateX, stateY ),6,Scalar( 0, 0, 255 ),-1,8 ); //画树上状态点

        if (drawMotion->getParent() != nullptr) // 如果父节点不空，即不是起点
        { // 打印父节点，画点和线
            double parentSateX = drawMotion->getParent()->getState()->as<ompl::base::RealVectorStateSpace::StateType>()->values[0];
            double parentSateY = drawMotion->getParent()->getState()->as<ompl::base::RealVectorStateSpace::StateType>()->values[1];
            circle( envImageCopy,Point( parentSateX, parentSateY ),6,Scalar( 0, 0, 255 ),-1,8 );
            line( envImageCopy, Point( parentSateX, parentSateY ), Point( stateX, stateY ), Scalar( 0, 255, 0 ), 2, CV_AA );
        }
    }
    // 画起点和终点, circle, 参数：图像、位置、半径、BRG颜色、填满圆、8联通绘图方式
    double startStateX = drawMotions[0]->getState()->as<ompl::base::RealVectorStateSpace::StateType>()->values[0];
    double startStateY = drawMotions[0]->getState()->as<ompl::base::RealVectorStateSpace::StateType>()->values[1];
    double goalStateX = goalState_->as<ompl::base::RealVectorStateSpace::StateType>()->values[0];
    double goalStateY = goalState_->as<ompl::base::RealVectorStateSpace::StateType>()->values[1];
    circle( envImageCopy,Point( startStateX, startStateY ),15,Scalar( 128, 128, 0 ),-1,8 );
    circle( envImageCopy,Point( goalStateX, goalStateY ),15,Scalar( 0, 255, 165 ),-1,8 );
    // 输出中间图像
    cv::namedWindow("path", CV_WINDOW_AUTOSIZE | CV_WINDOW_FREERATIO); // 配置OPENCV窗口
    cv::resize(envImageCopy, envImageResize, cv::Size(), 0.65, 0.65); // 改变窗口大小
    cv::imshow("path", envImageResize); // 显示窗口图像
    if (lastGoalMotion_)
    {
        for (int i = 0; i <= mPathSize - 1; ++i)
        { // 获取路径点x，y值，画最终规划路径线
            double pathSateX = mpath[i]->getState()->as<ompl::base::RealVectorStateSpace::StateType>()->values[0];
            double pathSateY = mpath[i]->getState()->as<ompl::base::RealVectorStateSpace::StateType>()->values[1];
            if (mpath[i]->getParent() != nullptr)
            {
                double pathParentSateX = mpath[i]->getParent()->getState()->as<ompl::base::RealVectorStateSpace::StateType>()->values[0];
                double pathParentSateY = mpath[i]->getParent()->getState()->as<ompl::base::RealVectorStateSpace::StateType>()->values[1];
                line( envImageCopy, Point( pathParentSateX, pathParentSateY ), Point( pathSateX, pathSateY ), Scalar( 255, 0, 0 ), 3, CV_AA );
            }
        }

        std::string graph = "/home/wangkuan/workspace/Documents/Graph/finalPath.ppm";
        cv::namedWindow("path", CV_WINDOW_AUTOSIZE | CV_WINDOW_FREERATIO);
        cv::resize(envImageCopy, envImageResize, cv::Size(), 0.65, 0.65);
        cv::imshow("path", envImageResize);
        cv::waitKey( 500000 );
    }
    cv::waitKey( 1 ); // 停留1毫秒
}
